// Unit Testing af krav nr 4 - App’en skal tillade en bruger at logge ind
const chai = require('chai');
const chaiHttp = require('chai-http');
const should = chai.should()

chai.use(chaiHttp);

describe('login', () => {
  describe('POST /login', () => {
    it('should return a 200 response if the email + password is registered', function(done){
      chai
      .request('http://localhost:3000/users')
      .post("/login")
      .send({email:"kawe21ad@student.cbs.dk", password:"153264"})
      .end((err, res) => {
        res.should.have.status(200)
        done()
      })  //Returnerer 200 hvis email + password er registreret i databasen

      describe('login', () => {
        describe('POST /login', () => {
      it('should return a 401 response if the password is incorrect but email is registered', function(done){
        chai
        .request('http://localhost:3000/users')
        .post("/login")
        .send({email:"kawe21ad@student.cbs.dk", password:"1234"})
        .end((err, res) => {
          res.should.have.status(401);
          done()
        })})}) //Returnerer 401 hvis password er forkert men email er registreret i databasen


        describe('login', () => {
          describe('POST /login', () => {
        it('should return a 404 response if the email is not registered', function(done){
          chai
          .request('http://localhost:3000/users')
          .post("/login")
          .send({email:"Hej@cbs.dk", password:"0000"})
          .end((err, res) => {
            res.should.have.status(404);
            done()
          })})}) //Returnerer 404 hvis email ikke er registreret i databasen.
    });
  })
  })})})