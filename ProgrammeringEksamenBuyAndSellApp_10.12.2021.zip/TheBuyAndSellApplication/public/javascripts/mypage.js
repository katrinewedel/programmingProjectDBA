document.addEventListener("DOMContentLoaded", (event) => {

  //Save User and Item to localStorage
  const user = localStorage.getItem("user");
  if (user) {
    var loginform = document.getElementById("loginform");
    loginform.style.display = 'none';
    loginform.style.visibility = "hidden";
    var username = document.getElementById("username");
    var userinfo = JSON.parse(user);
    username.innerHTML = "User: " + userinfo.email;

  } else {
    var userrecognized = document.getElementById('userrecognized');
    userrecognized.style.display = 'none';
    userrecognized.style.visibility = 'hidden';
  }


  const request = new XMLHttpRequest();
  const url = 'http://localhost:3000/items';
  request.open("GET", url);

  request.send();
  request.onload = (e) => {
    var items = JSON.parse(request.response);
    console.log(items);
    
    var itemTable = document.getElementById("items");
    var itemCount = itemTable.rows.length;
   for (var i = 1; i < itemCount; i++) {
    itemTable.deleteRow(i);
   }

    items['items'].forEach(item => {
      console.log(item);
      var row = itemTable.insertRow(1);

      var cellName = row.insertCell(0);
      var cellCategory = row.insertCell(1);
      var cellDescription = row.insertCell(2);
      var cellPrice = row.insertCell(3);
      var cellDelete = row.insertCell(4);

      cellName.innerHTML = item.name;
      cellCategory.innerHTML = item.category;
      cellDescription.innerHTML = item.description;
      cellPrice.innerHTML = item.price;
      cellDelete.innerHTML = '<a href="#">Delete Item</a> - <a href="#">Edit Item</a>';

    });


  };

  //Show Items for user
var usermail = JSON.parse(localStorage.getItem("user"))

  fetch("http://localhost:3000/items/seller/" + usermail.email, {
    method: "GET" })
    .then((response) => response.json())
    .then((response) => {
      console.log(response)
      if (response) {
        var itemTable = document.getElementById("items");
        var itemCount = itemTable.rows.length;
        console.log("itemCount: " + itemCount)

        // clear items from table
        for (var i = 1; i < itemCount; i++) {
         itemTable.deleteRow(1);
       }
        // insert items to table
        response.forEach(item => {
          var row = itemTable.insertRow(1);
    
          var cellName = row.insertCell(0);
          var cellCategory = row.insertCell(1);
          var cellDescription = row.insertCell(2);
          var cellPrice = row.insertCell(3);
    
          cellName.innerHTML = item.name;
          cellCategory.innerHTML = item.category;
          cellDescription.innerHTML = item.description;
          cellPrice.innerHTML = item.price;
    
        });

      } else {
        window.alert("Items cannot be retrieved");
      }
    })
    .catch((e) => {
      window.alert("Der skete en fejl", e);
    });



    //Login User
  document.getElementById("login_user_form").addEventListener("submit", (event) => {
    event.preventDefault();

    const email = document.getElementById("login_email").value;
    const password = document.getElementById("login_password").value;

    const user = {
      email: email,
      password: password,
    };

    fetch("http://localhost:3000/users/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(user),
    })
      .then((response) => response.json())
      .then((response) => {
        if (response) {

          // Gemme oplysninger
          localStorage.setItem("user", JSON.stringify(user));
          location.href = "/";
        } else {
          window.alert("Oplysninger forkert");
        }
      })
      .catch(() => {
        window.alert("Der skete en fejl");
      });
  });

  //Logout User
  document.getElementById("logout_link").addEventListener("click", (event) => {
    event.preventDefault();
    localStorage.removeItem("user");
    location.href = "/";
  });


  //Delete User
  document.getElementById("delete_user_link").addEventListener("click", (event) => {
    event.preventDefault();
    let user = JSON.parse(localStorage.getItem("user"));

    fetch("http://localhost:3000/users/delete/" + user.email, {
      method: "DELETE",
    })
      .then((response) => response.json())
      .then((response) => {
        if (response) {
          
          // Gemme oplysninger
          localStorage.removeItem("user");
          location.href = "/";
        } else {
          window.alert("Oplysninger forkert");
        }
      })
      .catch(() => {
        window.alert("Der skete en fejl");
      });

  
  
  });
  
  //Edit User
  document.getElementById("change_user_form").addEventListener("submit", (event) => {
    event.preventDefault();
    let user = JSON.parse(localStorage.getItem("user"));

    let name = document.getElementById("change_name").value


fetch("http://localhost:3000/users/update/" + user.email, {
  method: "PUT",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({name:name}),
})
  .then((response) => response.json())
  .then((response) => {
    if (response) {

      // Gemme oplysninger
      user.name = name
      localStorage.setItem("user", JSON.stringify(user));
      location.href = "/";
    } else {
      window.alert("Oplysninger forkert");
    }
  })
  .catch(() => {
    window.alert("Der skete en fejl");
  });

  
  
  });


});
