document.addEventListener("DOMContentLoaded", (event) => {

  // Create Item
    document.getElementById("create_item_form").addEventListener("submit", (event) => {
      event.preventDefault();
  
      const id = document.getElementById("id").value;
      const name = document.getElementById("name").value;
      const category = document.getElementById("category").value;
      const description = document.getElementById("description").value;
      const price = document.getElementById("price").value;
      var seller = JSON.parse(localStorage.getItem("user")).email

  
      const item = {
        id: id,
        name: name,
        category: category,
        description: description,
        price: price,
        seller: seller,

      };
  
      fetch("http://localhost:3000/items/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(item),
      })
        .then((response) => response.json())
        .then((response) => {
          if (response) {
            location.href = "mypage.html";
          }
        })
        .catch(() => {
          window.alert("Der skete en fejl");
        });
    });

    //Edit Item
    document.getElementById("edit_item_form").addEventListener("submit", (event) => {
        event.preventDefault();
    
        const id = document.getElementById("editid").value;
        const name = document.getElementById("editname").value;
        const category = document.getElementById("editcategory").value;
        const description = document.getElementById("editdescription").value;
        const price = document.getElementById("editprice").value;
        var seller = JSON.parse(localStorage.getItem("user")).email
  
    
        const item = {
          id: id,
          name: name,
          category: category,
          description: description,
          price: price,
          seller: seller,
  
        };
    
        fetch("http://localhost:3000/items/update", {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(item),
        })
          .then((response) => response.json())
          .then((response) => {
            if (response) {
              //location.href = "mypage.html";
            }
          })
          .catch(() => {
            window.alert("Der skete en fejl");
          });
      });


      //Delete item
      document.getElementById("deletebutton").addEventListener("click", (event) => {
        event.preventDefault();
    
        const id = document.getElementById("deleteId").value;

    
        fetch("http://localhost:3000/items/delete/" + id, {
          method: "DELETE",
        })
          .then((response) => response.json())
          .then((response) => {
            if (response) {
              //location.href = "mypage.html";
            }
          })
          .catch(() => {
            window.alert("Der skete en fejl");
          });
      });

  });
  
  