var express = require('express');
var router = express.Router();
var userModel = require("./../models/users");
var userFile = "./data/users.json";
var fs = require("fs");

/* GET users listing. */
router.get('/', function (req, res, next) {
  res.send('respond with a resource');
});

//Create user by email and password
router.post('/create', function (req, res, next) {
  try {
    var newUser = new userModel(req.body.email, req.body.password);

    var usersRaw = fs.readFileSync(userFile);
    var users = JSON.parse(usersRaw);

    users['users'].push(newUser);
    var newDataToSave = JSON.stringify(users,null, 2);
    fs.writeFileSync(userFile, newDataToSave);
    res.status(200).send(true);

  } catch (e) {
    res.status(500).send(false);
    console.log('Error in Create User function:', e);
  }
});

//Login user by email and password recognized in JSON-file
router.post("/login", function (req, res, next) {
  var user = new userModel(req.body.email, req.body.password);
console.log(user);
  var usersRaw = fs.readFileSync(userFile);
  var users = JSON.parse(usersRaw);
console.log(users);
  var found = users.users.find((x) => user.email == x.email);
console.log(found);
  if (found) {
    if (user.password == found.password) {
      res.status(200).send(true);
      console.log('User login: Login successfull.')
    } else {
      res.status(401).send(false);
      console.log('User login: Password incorrect.')
    }
  } else {
    res.status(404).send(false);
    console.log('User login: Unknown user.')
  }
});

//Delete user already logged in
router.delete("/delete/:email", (req,res, next) => {

  const useremail = req.params.email
  var usersRaw = fs.readFileSync(userFile);
  var users = JSON.parse(usersRaw);
  users.users.forEach((element, index) => {  
    if(element.email == useremail) {
      users.users.splice(index, 1)
      var newDataToSave = JSON.stringify(users ,null, 2);
      fs.writeFileSync(userFile, newDataToSave);
    }

  });

  res.status(200).send(true);
})

//Update email for user already logged in
router.put("/update/:email", (req,res, next) => {

  const useremail = req.params.email
  var usersRaw = fs.readFileSync(userFile);
  var users = JSON.parse(usersRaw);
  users.users.forEach((element, index) => {  
    if(element.email == useremail) {
      element.email = req.body.name
      var newDataToSave = JSON.stringify(users,null, 2);
      fs.writeFileSync(userFile, newDataToSave);
    }

  });

  res.status(200).send(true);
})

module.exports = router;