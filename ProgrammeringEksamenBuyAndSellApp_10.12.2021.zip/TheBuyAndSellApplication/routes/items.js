var express = require('express');
var router = express.Router();
var itemModel = require("../models/items");
var itemFile = "./data/items.json";
var fs = require("fs");
const { all } = require('./users');

/* GET all items listing. */
router.get('/', function (req, res, next) {
  var itemsRaw = fs.readFileSync(itemFile);
  var items = JSON.parse(itemsRaw);
  var allitems = items.items;
  console.log(allitems);
  res.send(allitems);
});

/* GET items listing by category. */
router.get('/category/:category', function (req, res, next) {
  var itemsRaw = fs.readFileSync(itemFile);
  var items = JSON.parse(itemsRaw);
  var filtered = items.items.filter(i => i.category === req.params.category)
  console.log(filtered);
  res.send(filtered);
});

/* GET items listing by seller. */
router.get('/seller/:seller', function (req, res, next) {
  var itemsRaw = fs.readFileSync(itemFile);
  var items = JSON.parse(itemsRaw);
  var allitems = items.items;
  var myItems = []

  allitems.forEach((element, index) => {  
    if(element.seller == req.params.seller) {
      myItems.push(element)
    }
  });
  res.send(myItems);
});


//Create items by id
router.post('/create', function (req, res, next) {
  try {
    var newItem = new itemModel(req.body.id, req.body.name, req.body.description, req.body.category, req.body.price, req.body.seller);

    var itemsRaw = fs.readFileSync(itemFile);
    var items = JSON.parse(itemsRaw);

    items['items'].push(newItem);
    var newDataToSave = JSON.stringify(items,null, 2);
    fs.writeFileSync(itemFile, newDataToSave);
    res.status(200).send(true);

  } catch (e) {
    res.status(500).send(false);
    console.log('Error in Create Item function:', e);
  }

});

router.delete("/delete/:id", (req,res, next) => {

  const id = req.params.id
  var itemsRaw = fs.readFileSync(itemFile);
  var items = JSON.parse(itemsRaw);
  items.items.forEach((element, index) => {  
    if(element.id == id) {
      items.items.splice(index, 1)
      var newDataToSave = JSON.stringify(items ,null, 2);
      fs.writeFileSync(itemFile, newDataToSave);
    }

  });

  res.status(200).send(true);
})

 router.put("/update/", (req,res, next) => {

  var itemsRaw = fs.readFileSync(itemFile);
  var items = JSON.parse(itemsRaw);
  items.items.forEach((element, index) => {  
    if(element.id == req.body.id) {
      element.name = req.body.name
      element.category = req.body.category
      element.description = req.body.description
      element.price = req.body.price
      var newDataToSave = JSON.stringify(items ,null, 2);
      fs.writeFileSync(itemFile, newDataToSave);
    }

  });
  res.status(200).send(true);
});

module.exports = router;