class Item {
  constructor(id, name, description, category, price, seller) {
    this.id = id;
    this.name = name;
    this.description = description;
    this.category = category;
    this.price = price;
    this.seller = seller;
  }
}

module.exports = Item;

