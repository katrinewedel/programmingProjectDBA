document.addEventListener("DOMContentLoaded", (event) => {


  //LocalStorage User
  const user = localStorage.getItem("user");
  if (user) {
    var loginform = document.getElementById("loginform");
    loginform.style.display = 'none';
    loginform.style.visibility = "hidden";
    var username = document.getElementById("username");
    var userinfo = JSON.parse(user);
    username.innerHTML = "User: " + userinfo.email;

  } else {
    var userrecognized = document.getElementById('userrecognized');
    userrecognized.style.display = 'none';
    userrecognized.style.visibility = 'hidden';
  }

  // Lookup items for sale
  const request = new XMLHttpRequest();
  var url = 'http://localhost:3000/items';
  request.open("GET", url);

  request.send();
  request.onload = (e) => {
    var items = JSON.parse(request.response);
    console.log(items);
    
    var itemTable = document.getElementById("items");
    var itemCount = itemTable.rows.length;
    // clear items from table
    for (var i = 1; i < itemCount; i++) {
    itemTable.deleteRow(i);
   }
    // insert items to table
    items.forEach(item => {
      console.log(item);
      var row = itemTable.insertRow(1);

      var cellName = row.insertCell(0);
      var cellCategory = row.insertCell(1);
      var cellDescription = row.insertCell(2);
      var cellPrice = row.insertCell(3);

      cellName.innerHTML = item.name;
      cellCategory.innerHTML = item.category;
      cellDescription.innerHTML = item.description;
      cellPrice.innerHTML = item.price;

    });


  };


//Login user
  document.getElementById("login_user_form").addEventListener("submit", (event) => {
    event.preventDefault();

    const email = document.getElementById("login_email").value;
    const password = document.getElementById("login_password").value;

    const user = {
      email: email,
      password: password,
    };

    fetch("http://localhost:3000/users/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(user),
    })
      .then((response) => response.json())
      .then((response) => {
        if (response) {
          // Save data to localStorage
          localStorage.setItem("user", JSON.stringify(user));
          location.href = "/";
        } else {
          window.alert("Oplysninger forkert");
        }
      })
      .catch(() => {
        window.alert("Der skete en fejl");
      });
  });

//Logout User
  document.getElementById("logout_link").addEventListener("click", (event) => {
    event.preventDefault();
    localStorage.removeItem("user");
    location.href = "/";
  });

  //Select Category
  document.getElementById("categories").addEventListener("change", (event) => {
    var select_box = document.getElementById("categories");
    var selected_category = select_box.value;
     console.log(selected_category);

  // Lookup items for sale
  const request = new XMLHttpRequest();
  if (selected_category === "all") {
      var url = 'http://localhost:3000/items';
    } else {
      var url = 'http://localhost:3000/items/category/' + selected_category;
    }
      request.open("GET", url);
console.log("url: " + url);
  request.send();
  request.onload = (e) => {
    var items = JSON.parse(request.response);
    console.log(items);
    
    var itemTable = document.getElementById("items");
    var itemCount = itemTable.rows.length;
    console.log("itemCount: " + itemCount)
    // clear items from table
    for (var i = 1; i < itemCount; i++) {
     itemTable.deleteRow(1);
   }
    // insert items to table
    
    items.forEach(item => {
      console.log(item);
      var row = itemTable.insertRow(1);

      var cellName = row.insertCell(0);
      var cellCategory = row.insertCell(1);
      var cellDescription = row.insertCell(2);
      var cellPrice = row.insertCell(3);

      cellName.innerHTML = item.name;
      cellCategory.innerHTML = item.category;
      cellDescription.innerHTML = item.description;
      cellPrice.innerHTML = item.price;

    });
  };

     
  });

});
