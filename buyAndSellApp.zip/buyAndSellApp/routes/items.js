var express = require('express');
var router = express.Router();

/* GET items listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

router.post('/create', function(req, res, next) {
  res.send('respond with a resource');
});

router.post('/edit', function(req, res, next) {
  res.send('respond with a resource');
});

router.post('/delete', function(req, res, next) {
  res.send('respond with a resource');
});

router.get('/:user', function(req, res, next) {
  res.send('respond with a resource');
});




module.exports = router;