//class is the definition of data, then you create an object which is the actual user
class User {
    //constructor er en funktion med tilhørende felter
    constructor(email, password) {
    //this (user) has an email, this (user) has a password
      this.email = email;
      this.password = password;
    }
  }
  
  module.exports = User;

  