//class is the definition of data, then you create an object which is the actual user
class Items {
    //constructor er en funktion med tilhørende felter
    constructor(name, category, price, description, user) {
    //this (item) has a name, etc..
      this.name = name;
      this.category = category;
      this.price = price;
      this.description = description;
      this.user = user;

    }
  }
  
  module.exports = Items;