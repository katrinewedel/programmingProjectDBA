document.addEventListener("DOMContentLoaded", (event) => {
    //tilgår storage og ser om der er en user
    const user = localStorage.getItem("user");
    //if user gør det her - finder loginform
    if (user) {
      var loginform = document.getElementById("loginform");
      loginform.style.display = 'none';
      loginform.style.visibility = "hidden";
      var username = document.getElementById("username");
      var userinfo = JSON.parse(user);
      username.innerHTML = "User: " + userinfo.email;
      
    } else
    {
      var userrecognized = document.getElementById('userrecognized');
      userrecognized.style.display = 'none';
      userrecognized.style.visibility = 'hidden';
    }
  
    document.getElementById("login_user_form").addEventListener("submit", (event) => {
      event.preventDefault();
  
      const email = document.getElementById("login_email").value;
      const password = document.getElementById("login_password").value;
  
      const user = {
        email: email,
        password: password,
      };
  
      fetch("http://localhost:3000/users/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(user),
      })
        .then((response) => response.json())
        .then((response) => {
          if (response) {
            // Gemme oplysninger
            localStorage.setItem("user", JSON.stringify(user));
            location.href = "/";
          } else {
            window.alert("Oplysninger forkert");
          }
        })
        .catch(() => {
          window.alert("Der skete en fejl");
        });
    });

    document.getElementById("logout_link").addEventListener("click", (event) => {
      event.preventDefault();
      localStorage.removeItem("user");
      location.href = "/";
    });


  });