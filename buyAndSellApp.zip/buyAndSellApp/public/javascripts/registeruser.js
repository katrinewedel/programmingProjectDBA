document.addEventListener("DOMContentLoaded", (event) => {
    document.getElementById("register_user_form").addEventListener("submit", (event) => {
      event.preventDefault();
  
      const email = document.getElementById("email").value;
      const password = document.getElementById("password").value;
  
      const user = {
        email: email,
        password: password,
      };
  
      fetch("http://localhost:3000/users/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(user),
      })
        .then((response) => response.json())
        .then((response) => {
          if (response) {
            window.alert("User has been created");
            location.href = "index.html";
          }
        })
        .catch(() => {
          window.alert("Der skete en fejl");
        });
    });
  });